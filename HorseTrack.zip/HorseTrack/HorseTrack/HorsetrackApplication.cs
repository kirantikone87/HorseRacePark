﻿using HorseTrack.HorseTrack.Service.Repository;
using HorseTrack.HorseTrack.Service.Repository.Interface;
using Microsoft.Extensions.DependencyInjection;

public class HorsetrackApplication
{
    /// <summary>
    /// Main- Application Entry point
    /// </summary>
    /// <param name="args"></param>
    public static void Main(string[] args)
    {
        // ServiceCollection - Added service scope/dependency injection
        var collection = new ServiceCollection();
        collection.AddScoped<IHorseRepository, HorseRepository>();
        collection.AddScoped<IInventoryRepository, InventoryRepository>();
        collection.AddScoped<IAccessorMode, AccessorMode>();
        
        IServiceProvider serviceProvider = collection.BuildServiceProvider();
        var horseRepository = serviceProvider.GetService<IHorseRepository>();
        var inventoryRepository = serviceProvider.GetService<IInventoryRepository>();
        var accessorMode = serviceProvider.GetService<IAccessorMode>();

        // initialize - default horses and inventories
        try
        {
            accessorMode?.Initialize(horseRepository, inventoryRepository);
            accessorMode?.PrintStartupMessages();

            if (accessorMode != null)
            {
                while (!(accessorMode.Quit()))
                {
                    Console.WriteLine("\nPlease enter the command:");
                    string? commandString = Console.ReadLine();
                    string? input = commandString?.Trim().Replace(@"\n", "");

                    if (input != null)
                    {
                        accessorMode.Execute(input);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }
        finally
        {
            // Dispose - reallocate service Provider memmory
            if (serviceProvider is IDisposable)
            {
                ((IDisposable)serviceProvider).Dispose();
            }
        }
        Console.ReadLine(); 
    }
}