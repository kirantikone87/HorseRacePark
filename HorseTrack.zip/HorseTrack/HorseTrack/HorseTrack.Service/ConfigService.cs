﻿using HorseTrack.Data.Context;
using HorseTrack.Data.Model;
using HorseTrack.HorseTrack.Data.Model.Enum;
using HorseTrack.HorseTrack.Service.Repository;
using HorseTrack.HorseTrack.Service.Repository.Interface;

namespace HorseTrack.Service
{
    public class ConfigService
    {
        private IHorseRepository horseRepository;
        private IInventoryRepository inventoryRepository;

        /// <summary>
        /// ConfigService - added dependent object
        /// </summary>
        /// <param name="apiContext"></param>
        public ConfigService()
        {
            horseRepository = new HorseRepository();
            inventoryRepository = new InventoryRepository();
        }

        /// <summary>
        /// loadHorses - load defaut horses info
        /// </summary>
        public void LoadHorses()
        {
            horseRepository.Insert(new Horse(1, "That Darn Gray Cat", 5, RaceStatus.WON));
            horseRepository.Insert(new Horse(2, "Fort Utopia", 10, RaceStatus.LOST));
            horseRepository.Insert(new Horse(3, "Count Sheep", 9, RaceStatus.LOST));
            horseRepository.Insert(new Horse(4, "Ms Traitour", 4, RaceStatus.LOST));
            horseRepository.Insert(new Horse(5, "Real Princess", 3, RaceStatus.LOST));
            horseRepository.Insert(new Horse(6, "Pa Kettle", 5, RaceStatus.LOST));
            horseRepository.Insert(new Horse(7, "Gin Stinger", 6, RaceStatus.LOST));
        }

        /// <summary>
        /// loadInventory - load inventory info
        /// </summary>
        public void LoadInventory()
        {
            inventoryRepository.Insert(new Inventory(1, 10));
            inventoryRepository.Insert(new Inventory(5, 10));
            inventoryRepository.Insert(new Inventory(10, 10));
            inventoryRepository.Insert(new Inventory(20, 10));
            inventoryRepository.Insert(new Inventory(100, 10));
        }

        /// <summary>
        /// startup - initilize
        /// </summary>
        public void Startup()
        {
            try
            {
                LoadHorses();
                LoadInventory();
            }
            catch (Exception ex)
            {
                Console.WriteLine("ConfigService -> Startup: " + ex.Message);
            }
        }
    }
}
