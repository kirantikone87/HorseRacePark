﻿using HorseTrack.Data.Context;
using HorseTrack.Data.Model;
using HorseTrack.HorseTrack.Service.Repository;
using HorseTrack.HorseTrack.Service.Repository.Interface;
using System.Configuration;

namespace HorseTrack.Service
{
    public class ReporterService
    {
        // Messages
        private string currencySymbol = "currency_symbol";

        private string messageInventory = "message_inventory";

        private string messageHorses = "message_horses";

        private string messageNoPayout = "message_no_payout";

        private string messagePayout = "message_payout";

        private string messageDispensing = "message_dispensing";

        // Error Messages        
        private string errorMessageInsufficientFunds = "error_message_insufficient_funds";

        private string errorMessageInvalidBet = "error_message_invalid_bet";

        private string errorMessageInvalidCommand = "error_message_invalid_command";

        private string errorMessageInvalidHorseNumber = "error_message_invalid_horse_number";

        private IHorseRepository horseRepository;

        private IInventoryRepository inventoryRepository;

        /// <summary>
        /// ReporterService - constructor
        /// </summary>
        /// <param name="apiContext"></param>
        public ReporterService()
        {
            horseRepository = new HorseRepository();
            inventoryRepository = new InventoryRepository();
        }

        /// <summary>
        /// printHorses - print Horses
        /// </summary>
        public void PrintHorses()
        {
            try
            {
                List<Horse> horses = horseRepository.FindAll();
                string? mValue = ConfigurationManager.AppSettings[messageHorses]?.ToString();
                Console.WriteLine("\n" + mValue);

                foreach (var horse in horses)
                {
                    Console.WriteLine(horse.GetHorseNumber()
                        + ", " + horse.GetHorseName()
                        + ", " + horse.GetOdds()
                        + ", " + horse.GetRaceStatus().ToString().ToLower());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ReporterService -> PrintHorses: " + ex.Message);
            }
        }

        /// <summary>
        /// printInventory- print Inventory
        /// </summary>
        public void PrintInventory()
        {
            try
            {
                List<Inventory> inventories = inventoryRepository.FindAll();
                string? iValue = ConfigurationManager.AppSettings[messageInventory]?.ToString();
                string? cValue = ConfigurationManager.AppSettings[currencySymbol]?.ToString();
                Console.WriteLine("\n" + iValue);

                foreach (var inventory in inventories)
                {
                    Console.WriteLine(cValue + inventory.GetDenomination() + ", " + inventory.GetBillCount());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ReporterService -> PrintInventory: " + ex.Message);
            }
        }

        /// <summary>
        /// printInvalidCommand - print Invalid Command Msg
        /// </summary>
        /// <param name="command"></param>
        public void PrintInvalidCommand(string command)
        {
            try
            {
                string? mValue = ConfigurationManager.AppSettings[errorMessageInvalidCommand]?.ToString();
                Console.WriteLine(mValue + " " + command);
            }
            catch (Exception ex)
            {
                Console.WriteLine("ReporterService -> PrintInvalidCommand: " + ex.Message);
            }
        }

        /// <summary>
        /// printInvalidHorse - print Invalid Horse Msg
        /// </summary>
        /// <param name="horseNumber"></param>
        public void PrintInvalidHorse(int horseNumber)
        {
            try
            {
                string? mValue = ConfigurationManager.AppSettings[errorMessageInvalidHorseNumber]?.ToString();
                Console.WriteLine(mValue + " " + horseNumber);
            }
            catch (Exception ex)
            {
                Console.WriteLine("ReporterService -> PrintInvalidHorse: " + ex.Message);
            }
        }

        /// <summary>
        /// printInvalidBet- print Invalid Bet Msg
        /// </summary>
        /// <param name="invalidBet"></param>
        public void PrintInvalidBet(string invalidBet)
        {
            try
            {
                string? mValue = ConfigurationManager.AppSettings[errorMessageInvalidBet]?.ToString();
                Console.WriteLine(mValue + " " + invalidBet);
            }
            catch (Exception ex)
            {
                Console.WriteLine("ReporterService -> PrintInvalidBet: " + ex.Message);
            }
        }

        /// <summary>
        /// printPayout- print Payout Msg
        /// </summary>
        /// <param name="horseName"></param>
        /// <param name="amountWon"></param>
        public void PrintPayout(string horseName, int amountWon)
        {
            try
            {
                string? cValue = ConfigurationManager.AppSettings[currencySymbol]?.ToString();
                string? mValue = ConfigurationManager.AppSettings[messagePayout]?.ToString();
                Console.WriteLine(mValue + " " + horseName + ", " + cValue + amountWon);
            }
            catch (Exception ex)
            {
                Console.WriteLine("ReporterService -> PrintPayout: " + ex.Message);
            }
        }

        /// <summary>
        /// printNoPayout- print No Payout Msg
        /// </summary>
        /// <param name="horseName"></param>
        public void PrintNoPayout(string horseName)
        {
            try
            {
                string? mValue = ConfigurationManager.AppSettings[messageNoPayout]?.ToString();
                Console.WriteLine(mValue + " " + horseName);
            }
            catch (Exception ex)
            {
                Console.WriteLine("ReporterService -> PrintNoPayout: " + ex.Message);
            }
        }

        /// <summary>
        /// printInsufficientFunds - print Insufficient Funds Msg
        /// </summary>
        /// <param name="amountWon"></param>
        public void PrintInsufficientFunds(int amountWon)
        {
            try
            {
                string? cValue = ConfigurationManager.AppSettings[currencySymbol]?.ToString();
                string? mValue = ConfigurationManager.AppSettings[errorMessageInsufficientFunds]?.ToString();
                Console.WriteLine(mValue + " " + cValue + amountWon);
            }
            catch (Exception ex)
            {
                Console.WriteLine("ReporterService -> PrintInsufficientFunds: " + ex.Message);
            }
        }

        /// <summary>
        /// printDispense - print Dispense Msg
        /// </summary>
        /// <param name="dispense"></param>
        public void PrintDispense(List<Wager> dispense)
        {
            try
            {
                string? cValue = ConfigurationManager.AppSettings[currencySymbol]?.ToString();
                string? mValue = ConfigurationManager.AppSettings[messageDispensing]?.ToString();
                Console.WriteLine("\n" + mValue);

                foreach (var wager in dispense)
                {
                    Console.WriteLine(cValue
                            + wager.GetDenomination()
                        + ", "
                            + wager.GetBillCount()
                            );
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ReporterService -> PrintDispense: " + ex.Message);
            }
        }

        /// <summary>
        /// printErrorMessage- print Error Message
        /// </summary>
        /// <param name="message"></param>
        public void PrintErrorMessage(string message)
        {
            Console.WriteLine(message);
        }

        /// <summary>
        /// startup - init
        /// </summary>
        public void Startup()
        {
            try
            {
                PrintInventory();
                PrintHorses();
            }
            catch (Exception ex)
            {
                Console.WriteLine("ReporterService -> Startup: " + ex.Message);
            }
        }
    }
}
