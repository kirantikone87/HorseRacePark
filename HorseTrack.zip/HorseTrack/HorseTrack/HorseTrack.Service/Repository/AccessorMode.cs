﻿using HorseTrack.Data.Context;
using HorseTrack.Data.Model;
using HorseTrack.HorseTrack.Service.Repository.Interface;
using HorseTrack.Service;

namespace HorseTrack.HorseTrack.Service.Repository
{
    public class AccessorMode : IAccessorMode
    {
        public bool q = false;
        HorseService horseService;
        InventoryService inventoryService;
        ConfigService configService;
        CommandService commandService;
        ReporterService reporterService;

        /// <summary>
        /// default initilization
        /// </summary>
        public AccessorMode()
        {
            this.commandService = new CommandService();
            this.configService = new ConfigService();
            this.reporterService = new ReporterService();
        }

        /// <summary>
        /// initialize - init
        /// </summary>
        public void Initialize(IHorseRepository? horseRepository, IInventoryRepository? inventoryRepository)
        {
            try
            {
                this.horseService = new HorseService(horseRepository);
                this.inventoryService = new InventoryService(inventoryRepository);
                configService.Startup();
            }
            catch (Exception ex)
            {
                Console.WriteLine("AccessorMode -> Initialize Method: " + ex.Message);
            }
        }

        /// <summary>
        /// execute - validate input
        /// </summary>
        /// <param name="commandLine"></param>
        public void Execute(string commandLine)
        {
            Console.WriteLine("\nCommand issued: " + commandLine);
            try
            {
                if (commandLine.Length > 0)
                {
                    if (commandService.ParseCommand(commandLine).ToLower().Equals("invalid"))
                    {
                        reporterService.PrintInvalidCommand(commandLine);
                    }
                    else
                    {
                        CommandFactory(commandLine);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("AccessorMode -> Execute Method: " + ex.Message);
            }
        }

        /// <summary>
        /// commandFactory - excuting entered command operations
        /// </summary>
        /// <param name="commandLine"></param>
        public void CommandFactory(string commandLine)
        {
            try
            {
                string command = commandService.ParseCommand(commandLine);
                switch (command)
                {
                    case "quit":
                        q = true;
                        break;
                    case "restock":
                        Restock();
                        break;
                    case "winner":
                        Winner(commandService.GetWinningHorseNumber());
                        break;
                    case "wager":
                        Wager(commandService.GetBetHorseNumber(), commandService.GetWagerAmount());
                        break;
                    case "error":
                        reporterService.PrintErrorMessage(commandService.GetErrorMessage());
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("AccessorMode -> CommandFactory Method: " + ex.Message);
            }
        }

        /// <summary>
        /// quit - exit cmd
        /// </summary>
        /// <returns></returns>
        public bool Quit()
        {
            return q;
        }

        /// <summary>
        /// restock - restock bill amt
        /// </summary>
        public void Restock()
        {
            inventoryService.Restock();
            reporterService.PrintInventory();
        }

        /// <summary>
        /// wager - print Payout and Dispense
        /// </summary>
        /// <param name="horseNumber"></param>
        /// <param name="wagerAmount"></param>

        public void Wager(int horseNumber, int wagerAmount)
        {
            try
            {
                if (!horseService.IsValidHorseNumber(horseNumber))
                {
                    reporterService.PrintInvalidHorse(horseNumber);
                    return;
                }

                if (!horseService.IsHorseWinner(horseNumber))
                {
                    reporterService.PrintNoPayout(horseService.GetHorseName(horseNumber));
                    return;
                }

                int amountWon = CalculateAmountWon(
                wagerAmount,
                    horseService.GetHorseOdds(horseNumber));

                if (inventoryService.SufficientFunds(amountWon))
                {
                    reporterService.PrintPayout(horseService.GetHorseName(horseNumber), amountWon);
                    reporterService.PrintDispense(DispenseWinnings(amountWon));
                }
                else
                {
                    reporterService.PrintInsufficientFunds(amountWon);
                }

                reporterService.PrintInventory();
                reporterService.PrintHorses();
            }
            catch (Exception ex)
            {
                Console.WriteLine("AccessorMode -> Wager Method: " + ex.Message);
            }
        }

        /// <summary>
        /// winner - set the winner
        /// </summary>
        /// <param name="horseNumber"></param>
        public void Winner(int horseNumber)
        {
            try
            {
                if (horseService.IsValidHorseNumber(horseNumber))
                {
                    horseService.SetRaceWinner(horseNumber);
                    reporterService.PrintInventory();
                    reporterService.PrintHorses();
                }
                else
                {
                    reporterService.PrintInvalidHorse(horseNumber);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("AccessorMode -> Winner Method: " + ex.Message);
            }
        }

        /// <summary>
        /// printStartupMessages - print Startup Messages
        /// </summary>
        public void PrintStartupMessages()
        {
            try
            {
                reporterService.Startup();
            }
            catch (Exception ex)
            {
                Console.WriteLine("AccessorMode -> PrintStartupMessages Method: " + ex.Message);
            }
        }

        #region "Private Functions"        

        private int CalculateAmountWon(int wager, int odds)
        {
            return wager * odds;
        }

        /// <summary>
        /// dispenseWinnings-dispense Winnings
        /// </summary>
        /// <param name="winnings"></param>
        /// <returns></returns>
        private List<Wager> DispenseWinnings(int winnings)
        {
            var wagerList = new List<Wager>();
            Wager wager;
            bool wagerAdded = false;
            var denoms = new List<int>();

            try
            {
                foreach (var inventory in inventoryService.GetInventory())
                {
                    denoms.Add(inventory.GetDenomination());
                }
                denoms.Reverse();

                foreach (var denomination in denoms)
                {
                    int bill = denomination;
                    wagerAdded = false;
                    for (int cnt = inventoryService.GetInventory(bill).GetBillCount(); cnt > 0; cnt--)
                    {
                        int totalAmountOfBills = bill * cnt;
                        if (winnings >= totalAmountOfBills)
                        {
                            wager = new Wager(bill, cnt);
                            wagerList.Add(wager);
                            wagerAdded = true;
                            winnings -= totalAmountOfBills;
                            break;
                        }
                    }
                    if (!wagerAdded)
                    {
                        wager = new Wager(bill, 0);
                        wagerList.Add(wager);
                    }
                }

                foreach (var k in wagerList)
                {
                    inventoryService.DecrementInventory(k.GetDenomination(), k.GetBillCount());
                }

                return wagerList;
            }
            catch (Exception ex)
            {
                Console.WriteLine("WagerService -> DispenseWinnings: " + ex.Message);
                return wagerList;
            }
        }
        #endregion
    }
}
