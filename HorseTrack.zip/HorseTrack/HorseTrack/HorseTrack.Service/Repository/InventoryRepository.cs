﻿using HorseTrack.Data.Context;
using HorseTrack.Data.Model;
using HorseTrack.HorseTrack.Service.Repository.Interface;

namespace HorseTrack.HorseTrack.Service.Repository
{
    /// <summary>
    /// InventoryRepository - Inventory Services Implementation
    /// </summary>
    public class InventoryRepository : IInventoryRepository
    {
        private ApiContext context;

        /// <summary>
        /// inject apiContext dependency thru constructor
        /// </summary>
        /// <param name="apiContext"></param>
        public InventoryRepository()
        {
            this.context = ApiContext.GetInstance;
        }

        /// <summary>
        /// insert - Add new inventory
        /// </summary>
        /// <param name="inventory"></param>
        public void Insert(Inventory inventory)
        {
            if (inventory != null)
            {
                try
                {
                    context.Inventories.Add(inventory);
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("InventoryRepository -> Insert: " + ex.Message);
                }
            }
        }

        /// <summary>
        /// findAll - get all inventories list
        /// </summary>
        /// <returns></returns>
        public List<Inventory> FindAll()
        {
            try
            {
                var inventories = context.Inventories.ToList();
                return inventories;
            }
            catch (Exception ex)
            {
                Console.WriteLine("InventoryRepository -> FindAll: " + ex.Message);
                return new List<Inventory>();
            }
        }

        /// <summary>
        /// findByDenominationEquals - getDenomination by denomination param
        /// </summary>
        /// <param name="denomination"></param>
        /// <returns></returns>
        public Inventory FindByDenominationEquals(int denomination)
        {
            try
            {
                var inventory = context.Inventories.ToList().Where(h => h.GetDenomination().Equals(denomination)).ToList();
                if (inventory != null && inventory.Count > 0)
                {
                    return inventory[0];
                }
                else
                {
                    return new Inventory();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("InventoryRepository -> FindByDenominationEquals: " + ex.Message);
                return new Inventory();
            }
        }
    }
}
