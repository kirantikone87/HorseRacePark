﻿using HorseTrack.Service;

namespace HorseTrack.HorseTrack.Service.Repository.Interface
{
    /// <summary>
    /// AccessorMode - declare services
    /// </summary>
    public interface IAccessorMode
    {
        public bool Quit();
        public void Restock();
        public void Wager(int horseNumber, int wagerAmount);
        public void Winner(int horse);
        public void PrintStartupMessages();
        public void Initialize(IHorseRepository? horseRepository, IInventoryRepository? inventoryRepository);
        public void Execute(string commandLine);
    }
}
