﻿using HorseTrack.Data.Model;

namespace HorseTrack.HorseTrack.Service.Repository.Interface
{
    /// <summary>
    /// IInventoryRepository- declare required services
    /// </summary>
    public interface IInventoryRepository
    {
        List<Inventory> FindAll();

        Inventory FindByDenominationEquals(int denomination);

        void Insert(Inventory inventory);
    }
}
