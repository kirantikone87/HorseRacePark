﻿using HorseTrack.Data.Model;

namespace HorseTrack.HorseTrack.Service.Repository.Interface
{
    /// <summary>
    /// IHorseRepository- Declare required services 
    /// </summary>
    public interface IHorseRepository
    {
        List<Horse> FindAll();

        Horse FindByHorseNumberEquals(int horseNumber);

        void Insert(Horse horse);
    }
}