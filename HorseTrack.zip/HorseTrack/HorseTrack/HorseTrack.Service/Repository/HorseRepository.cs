﻿using HorseTrack.Data.Context;
using HorseTrack.Data.Model;
using HorseTrack.HorseTrack.Service.Repository.Interface;


namespace HorseTrack.HorseTrack.Service.Repository
{
    /// <summary>
    /// HorseRepository- Service implementations
    /// </summary>
    public class HorseRepository : IHorseRepository
    {
        private ApiContext context;

        /// <summary>
        /// inject apiContext dependency thru constructor
        /// </summary>
        /// <param name="apiContext"></param>
        public HorseRepository()
        {
            this.context = ApiContext.GetInstance;
        }

        /// <summary>
        /// insert- add horse in list
        /// </summary>
        /// <param name="horse"></param>
        public void Insert(Horse horse)
        {
            try
            {
                if (horse != null)
                {
                    context.Horses.Add(horse);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("HorseRepository -> Insert: " + ex.Message);
            }
        }

        /// <summary>
        /// findAll - get all horses
        /// </summary>
        /// <returns></returns>
        public List<Horse> FindAll()
        {
            try
            {
                var horses = context.Horses.ToList();
                return horses;
            }
            catch (Exception ex)
            {
                Console.WriteLine("HorseRepository -> FindAll: " + ex.Message);
                return new List<Horse>();
            }
        }

        /// <summary>
        /// findByHorseNumberEquals - get horse by horse number
        /// </summary>
        /// <param name="horseNumber"></param>
        /// <returns></returns>
        public Horse FindByHorseNumberEquals(int horseNumber)
        {
            try
            {
                var horse = context.Horses.ToList().Where(h => h.GetHorseNumber().Equals(horseNumber)).ToList();
                if (horse != null && horse.Count > 0)
                {
                    return horse[0];
                }
                else
                {
                    return new Horse();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("HorseRepository -> FindByHorseNumberEquals: " + ex.Message);
                return new Horse();
            }
        }
    }
}
