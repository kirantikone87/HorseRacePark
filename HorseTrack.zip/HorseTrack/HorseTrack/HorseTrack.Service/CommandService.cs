﻿using System.Configuration;
using System.Text.RegularExpressions;

namespace HorseTrack.Service
{
    public class CommandService
    {
        private string? errorMessageInvalidBet = "error_message_invalid_bet";
        private string? errorMessageInvalidHorseNumber = "error_message_invalid_horse_number";

        private int betHorseNumber;
        private string currentCommand;
        private int wagerAmount;
        private int winningHorseNumber;
        private string errorMessage;

        /// <summary>
        /// CommandService- default constructor init
        /// </summary>
        public CommandService()
        {
            errorMessageInvalidBet = ConfigurationManager.AppSettings[errorMessageInvalidBet]?.ToString();
            errorMessageInvalidHorseNumber = ConfigurationManager.AppSettings[errorMessageInvalidHorseNumber]?.ToString();
        }

        /// <summary>
        /// parseCommand - validate the input command here
        /// </summary>
        /// <param name="commandLine"></param>
        /// <returns></returns>
        public string ParseCommand(string commandLine)
        {
            try
            {
                string[] commandComponents = commandLine.Trim().Split(" ").ToArray();

                string pattern = "[W,w] [1-9]";
                Match m = Regex.Match(commandLine, pattern, RegexOptions.IgnoreCase);

                string patternReg = "[0-9]+ [0-9]+.?[0-9]*";
                Match r = Regex.Match(commandLine, patternReg, RegexOptions.IgnoreCase);

                if (commandComponents[0].ToLower() == "q")
                {
                    currentCommand = "quit";
                    return currentCommand;
                }
                else if (commandComponents[0].ToLower() == "r")
                {
                    currentCommand = "restock";
                    return currentCommand;
                }
                else if (m.Success)
                {
                    winningHorseNumber = Convert.ToInt32(commandComponents[1]);
                    currentCommand = "winner";
                    return currentCommand;
                }
                else if (r.Success)
                {
                    betHorseNumber = Convert.ToInt32(commandComponents[0]);
                    try
                    {
                        wagerAmount = Convert.ToInt32(commandComponents[1]);
                    }
                    catch (FormatException e)
                    {
                        errorMessage = errorMessageInvalidBet + " " + commandComponents[1];
                        currentCommand = "error";
                        return currentCommand;
                    }
                    currentCommand = "wager";
                    return currentCommand;
                }
                else
                {
                    currentCommand = "invalid";
                    return currentCommand;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("CommandService -> ParseCommand:" + ex.Message);
                currentCommand = "error";
                return currentCommand;
            }
        }

        public string GetCurrentCommand()
        {
            return currentCommand;
        }

        public int GetBetHorseNumber()
        {
            return betHorseNumber;
        }

        public string GetErrorMessage()
        {
            return errorMessage;
        }

        public int GetWagerAmount()
        {
            return wagerAmount;
        }

        public int GetWinningHorseNumber()
        {
            return winningHorseNumber;
        }
    }
}
