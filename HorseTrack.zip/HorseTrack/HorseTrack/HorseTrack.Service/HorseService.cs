﻿using HorseTrack.Data.Context;
using HorseTrack.Data.Model;
using HorseTrack.HorseTrack.Data.Model.Enum;
using HorseTrack.HorseTrack.Service.Repository.Interface;

namespace HorseTrack.Service
{
    public class HorseService
    {
        private readonly IHorseRepository horseRepository;
        private ApiContext apiContext;

        /// <summary>
        /// HorseService - inject dependent obj
        /// </summary>
        /// <param name="horseRepository"></param>
        /// <param name="apiContext"></param>
        public HorseService(IHorseRepository horseRepository)
        {
            this.horseRepository = horseRepository;
            this.apiContext = ApiContext.GetInstance;
        }

        /// <summary>
        /// getHorseName- get Horse Name by horse Number
        /// </summary>
        /// <param name="horseNumber"></param>
        /// <returns></returns>
        public string GetHorseName(int horseNumber)
        {
            Horse horse = horseRepository.FindByHorseNumberEquals(horseNumber);
            return horse.GetHorseName();
        }

        /// <summary>
        /// getHorseOdds- get Horse Odds by horse Number
        /// </summary>
        /// <param name="horseNumber"></param>
        /// <returns></returns>
        public int GetHorseOdds(int horseNumber)
        {
            Horse horse = horseRepository.FindByHorseNumberEquals(horseNumber);
            return horse.GetOdds();
        }

        /// <summary>
        /// isHorseWinner - check is Horse Winner
        /// </summary>
        /// <param name="horseNumber"></param>
        /// <returns></returns>
        public bool IsHorseWinner(int horseNumber)
        {
            Horse horse = horseRepository.FindByHorseNumberEquals(horseNumber);
            if (horse.GetRaceStatus() == RaceStatus.WON)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// isValidHorseNumber- validate Horse Number
        /// </summary>
        /// <param name="horseNumber"></param>
        /// <returns></returns>
        public bool IsValidHorseNumber(int horseNumber)
        {
            if (horseRepository.FindByHorseNumberEquals(horseNumber) == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// setRaceWinner - update race winner
        /// </summary>
        /// <param name="horseNumber"></param>
        public void SetRaceWinner(int horseNumber)
        {
            try
            {
                List<Horse> horses = horseRepository.FindAll();
                foreach (var horse in horses)
                {
                    if (horse.GetRaceStatus() == RaceStatus.WON)
                    {
                        horse.SetRaceStatus(RaceStatus.LOST);
                        apiContext.SaveChanges();
                    }
                }

                foreach (var horse in horses)
                {
                    if (horse.GetHorseNumber() == horseNumber)
                    {
                        horse.SetRaceStatus(RaceStatus.WON);
                        apiContext.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("HorseService -> SetRaceWinner :" + ex.ToString());
            }
        }
    }
}
