﻿using HorseTrack.Data.Context;
using HorseTrack.Data.Model;
using HorseTrack.HorseTrack.Service.Repository.Interface;
using System.Configuration;

namespace HorseTrack.Service
{
    public class InventoryService
    {
        private int restockAmount;
        private IInventoryRepository inventoryRepository;
        private ApiContext apiContext;

        public InventoryService() 
        {
            restockAmount = Convert.ToInt32(ConfigurationManager.AppSettings["restock_amount"]?.ToString());
        }

        /// <summary>
        /// inject inventoryRepository, apiContext dependency thru constructor
        /// </summary>
        /// <param name="inventoryRepository"></param>
        /// <param name="apiContext"></param>
        public InventoryService(IInventoryRepository inventoryRepository)
        {
            this.inventoryRepository = inventoryRepository;
            this.apiContext = ApiContext.GetInstance;
            restockAmount = Convert.ToInt32(ConfigurationManager.AppSettings["restock_amount"]?.ToString());
        }

        /// <summary>
        /// restock - restock the bill count
        /// </summary>
        public void Restock()
        {
            try
            {
                List<Inventory> inventories = inventoryRepository.FindAll();
                foreach (var inventorie in inventories)
                {
                    inventorie.SetBillCount(restockAmount);
                    apiContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("InventoryService -> Restock: " + ex.Message);
            }
        }

        /// <summary>
        /// decrementInventory - update the Inventory
        /// </summary>
        /// <param name="denomination"></param>
        /// <param name="amount"></param>
        public void DecrementInventory(int denomination, int amount)
        {
            try
            {
                Inventory inventory = inventoryRepository.FindByDenominationEquals(denomination);
                int currentBillCount = inventory.GetBillCount();

                if ((currentBillCount - amount) >= 0)
                {
                    inventory.SetBillCount(currentBillCount - amount);
                    apiContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("InventoryService -> DecrementInventory: " + ex.Message);
            }
        }

        /// <summary>
        /// sufficientFunds - verify the sufficient Funds
        /// </summary>
        /// <param name="amountWon"></param>
        /// <returns></returns>
        public bool SufficientFunds(int amountWon)
        {
            List<Inventory> inventories = inventoryRepository.FindAll();
            Int32 result = 0;
            foreach (var inventorie in inventories)
            {
                result += inventorie.GetDenomination() * inventorie.GetBillCount();
            }

            if ((result - amountWon) >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// getInventory - get all Inventory
        /// </summary>
        /// <returns></returns>
        public List<Inventory> GetInventory()
        {
            try
            {
                return inventoryRepository.FindAll();
            }
            catch (Exception ex)
            {
                Console.WriteLine("InventoryService -> GetInventory: " + ex.Message);
                return new List<Inventory>();
            }
        }

        /// <summary>
        /// getInventory - get Inventory by denomination
        /// </summary>
        /// <param name="denomination"></param>
        /// <returns></returns>
        public Inventory GetInventory(int denomination)
        {
            try
            {
                return inventoryRepository.FindByDenominationEquals(denomination);
            }
            catch (Exception ex)
            {
                Console.WriteLine("InventoryService -> GetInventory: " + ex.Message);
                return new Inventory();
            }
        }
    }
}
