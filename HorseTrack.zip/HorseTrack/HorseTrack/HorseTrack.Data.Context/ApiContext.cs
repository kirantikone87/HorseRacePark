﻿using HorseTrack.Data.Model;
using Microsoft.EntityFrameworkCore;

namespace HorseTrack.Data.Context
{
    /// <summary>
    /// ApiContext - in memmory entity implementaions
    /// </summary>
    public class ApiContext : DbContext
    {
        private static object lockThis = new object();
        private static ApiContext? instance = null;
        private ApiContext() { }

        public static ApiContext GetInstance
        {
            get
            {
                lock (lockThis)
                {
                    if (instance == null)
                        instance = new ApiContext();

                    return instance;
                }
            }
        }

        /// <summary>
        /// create- In Memory Database
        /// </summary>
        /// <param name="optionsBuilder"></param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase(databaseName: "HorseTrackDb");
        }

        /// <summary>
        /// create/apply identity on id column
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Horse>().Property(p => p.id).ValueGeneratedOnAdd();
            modelBuilder.Entity<Inventory>().Property(p => p.id).ValueGeneratedOnAdd();
        }

        public DbSet<Horse> Horses { get; set; }
        public DbSet<Inventory> Inventories { get; set; }
    }
}