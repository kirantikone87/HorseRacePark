﻿using HorseTrack.HorseTrack.Data.Model.Enum;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace HorseTrack.Data.Model
{
    /// <summary>
    /// Model Horse
    /// </summary>
    public class Horse
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }

        private int horseNumber;

        private string horseName;

        private int odds;

        private RaceStatus raceStatus = RaceStatus.LOST;

        public Horse()
        {
        }

        public Horse(int horseNumber, string horseName, int odds, RaceStatus raceStatus)
        {
            this.horseNumber = horseNumber;
            this.horseName = horseName;
            this.odds = odds;
            this.raceStatus = raceStatus;
        }

        public int GetHorseNumber()
        {
            return horseNumber;
        }

        public void SetHorseNumber(int horseNumber)
        {
            this.horseNumber = horseNumber;
        }

        public string GetHorseName()
        {
            return horseName;
        }

        public void SetHorseName(string horseName)
        {
            this.horseName = horseName;
        }

        public int GetOdds()
        {
            return odds;
        }

        public void SetOdds(int odds)
        {
            this.odds = odds;
        }

        public RaceStatus GetRaceStatus()
        {
            return raceStatus;
        }

        public void SetRaceStatus(RaceStatus raceStatus)
        {
            this.raceStatus = raceStatus;
        }

        /// <summary>
        /// override string ToString function
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder("Horse{");
            sb.Append("id=").Append(id);
            sb.Append(", horseNumber=").Append(horseNumber);
            sb.Append(", horseName='").Append(horseName).Append('\'');
            sb.Append(", odds=").Append(odds);
            sb.Append(", raceStatus=").Append(raceStatus);
            sb.Append('}');
            return sb.ToString();
        }
    }
}
