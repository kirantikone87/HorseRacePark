﻿namespace HorseTrack.HorseTrack.Data.Model.Enum
{
    /// <summary>
    /// enum RaceStatus
    /// </summary>
    public enum RaceStatus
    {
        WON,
        LOST
    }
}
