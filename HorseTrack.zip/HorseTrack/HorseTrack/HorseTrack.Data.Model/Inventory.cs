﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace HorseTrack.Data.Model
{
    /// <summary>
    /// model Inventory
    /// </summary>
    public class Inventory
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }

        private int denomination;

        private int billCount;

        public Inventory()
        {
        }

        public Inventory(int denomination, int billCount)
        {
            this.denomination = denomination;
            this.billCount = billCount;
        }

        public int GetDenomination()
        {
            return denomination;
        }

        public void SetDenomination(int denomination)
        {
            this.denomination = denomination;
        }

        public int GetBillCount()
        {
            return billCount;
        }

        public void SetBillCount(int billCount)
        {
            this.billCount = billCount;
        }

        /// <summary>
        /// override string ToString
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder("Inventory{");
            sb.Append("id=").Append(id);
            sb.Append(", denomination=").Append(denomination);
            sb.Append(", billCount=").Append(billCount);
            sb.Append('}');
            return sb.ToString();
        }
    }
}
