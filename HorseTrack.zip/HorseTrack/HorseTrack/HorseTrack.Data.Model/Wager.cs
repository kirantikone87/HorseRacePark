﻿using System.Text;

namespace HorseTrack.Data.Model
{
    /// <summary>
    /// model wager
    /// </summary>
    public class Wager
    {
        private readonly int denomination;
        private readonly int billCount;

        public Wager(int denomination, int billCount)
        {
            this.denomination = denomination;
            this.billCount = billCount;
        }

        public int GetDenomination()
        {
            return denomination;
        }

        public int GetBillCount()
        {
            return billCount;
        }

        /// <summary>
        /// override string ToString
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder("Wager{");
            sb.Append("denomination=").Append(denomination);
            sb.Append(", billCount=").Append(billCount);
            sb.Append('}');
            return sb.ToString();
        }
    }
}
