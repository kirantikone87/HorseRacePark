﻿using HorseTrack.HorseTrack.Service.Repository;
using HorseTrack.HorseTrack.Service.Repository.Interface;

namespace HorseTrack.Test
{
    [TestClass]
    public class AccessorModeTest
    {
        AccessorMode accessorModeService = new AccessorMode();
        IHorseRepository horseRepository = new HorseRepository();
        IInventoryRepository inventoryRepository = new InventoryRepository();

        [TestMethod]
        public void TestInitialize()
        {
            try
            {
                accessorModeService.Initialize(horseRepository, inventoryRepository);
                accessorModeService.PrintStartupMessages();
            }
            catch (Exception ex)
            {
                Assert.IsFalse(true);
            }
            finally
            {
                Assert.IsTrue(true);
            }
        }

        [TestMethod]
        public void TestExecute()
        {
            try
            {
                accessorModeService.Initialize(horseRepository, inventoryRepository);
                accessorModeService.PrintStartupMessages();
                var commandString = "W 5";
                accessorModeService.Execute(commandString);
            }
            catch (Exception ex)
            {
                Assert.IsFalse(true);
            }
            finally
            {
                Assert.IsTrue(true);
            }
        }
    }
}
