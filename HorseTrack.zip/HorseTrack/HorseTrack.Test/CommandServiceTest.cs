using HorseTrack.Service;

namespace HorseTrack.Test
{
    [TestClass]
    public class CommandServiceTest
    {
        CommandService commandService = new CommandService();

        [TestMethod]
        public void TestParseCommandWinner()        {
            var commandString = "W 5";
            var expected = "winner";
            var actual = commandService.ParseCommand(commandString);
            Assert.AreEqual(expected, actual, "Incorrect command returned");
        }

        [TestMethod]
        public void TestParseCommandWager()
        {
            var commandString = "1 55";
            var expected = "wager";
            var actual = commandService.ParseCommand(commandString);
            Assert.AreEqual(expected, actual, "Incorrect command returned");
        }

        [TestMethod]
        public void TestParseCommandWagerError()
        {
            var commandString = "1 5.5";
            var expected = "error";
            var actual = commandService.ParseCommand(commandString);
            Assert.AreEqual(expected, actual, "Incorrect command returned");
        }

        [TestMethod]
        public void TestParseCommandQuit()
        {
            var commandString = "q";
            var expected = "quit";
            var actual = commandService.ParseCommand(commandString);
            Assert.AreEqual(expected, actual, "Incorrect command returned");
        }

        [TestMethod]
        public void TestParseCommandRestock()
        {
            var commandString = "R";
            var expected = "restock";
            var actual = commandService.ParseCommand(commandString);
            Assert.AreEqual(expected, actual, "Incorrect command returned");
        }

        [TestMethod]
        public void TestParseCommandInvalid()
        {
            var commandString = "X";
            var expected = "invalid";
            var actual = commandService.ParseCommand(commandString);
            Assert.AreEqual(expected, actual, "Incorrect command returned");
        }
    }
}